package com.example.tastebuds;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.method.LinkMovementMethod;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    Button lbutton;
    TextView Usernametxt,log;
    EditText Password123,Username;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Usernametxt = (TextView)findViewById(R.id.Usernametxt);
        log = (TextView)findViewById(R.id.log);
        lbutton = (Button)findViewById(R.id.lbutton);
        Password123 = (EditText)findViewById(R.id.Password);
        Username = (EditText)findViewById(R.id.Username);
        lbutton.setMovementMethod(LinkMovementMethod.getInstance());
        lbutton.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)

            {
                if(Password123.getText().toString().equals("admin") &&
                        Username.getText().toString().equals("admin")) {
                    Toast.makeText(getApplicationContext(),"Redirecting...", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                    startActivity(intent);
                }
                else {
                    Toast.makeText(getApplicationContext(), "Wrong Credentials",Toast.LENGTH_SHORT).show();
                }
            }

        });

    }
}