package com.example.tastebuds;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;

import java.util.Calendar;
import java.util.zip.DataFormatException;

public class MainActivity6 extends AppCompatActivity {
    TextView listView,priceView,tv,timer1,timer2;
    String list_choice;
    Double price_rs;
    Calendar mCurrentDate;
    int day, month, year;
    int t1Hour,t1Minute,t2Hour,t2Minute;
    Button button;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        listView=(TextView)findViewById(R.id.listView);
        priceView=(TextView)findViewById(R.id.priceView);
        Bundle bundle=getIntent().getExtras();
        list_choice=bundle.getString("choices");
        price_rs=bundle.getDouble("price");
        button=(Button)findViewById(R.id.button4);
        listView.setText(list_choice);
        priceView.setText(price_rs.toString() );
        tv=(TextView)findViewById(R.id.tv);
        mCurrentDate=Calendar.getInstance();
        day=mCurrentDate.get(Calendar.DAY_OF_MONTH);
        month=mCurrentDate.get(Calendar.MONTH);
        month=mCurrentDate.get(Calendar.MONTH);
        timer1=findViewById(R.id.timer1);

        month=month+1;
        tv.setText(day+"/"+month+"/"+year);
        tv.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v) {
                DatePickerDialog datePickerDialog=new DatePickerDialog(MainActivity6.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                        monthOfYear=monthOfYear+1;
                        tv.setText(day+"/"+month+"/"+year);


                    }
                },year,month,day);
                datePickerDialog.show();
            }
        });
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity6.this, MainActivity8.class);
                startActivity(intent);
            }

        });
        timer1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TimePickerDialog timePickerDialog=new TimePickerDialog(
                        MainActivity6.this,
                        new TimePickerDialog.OnTimeSetListener() {
                            @Override
                            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                                t1Hour=hourOfDay;
                                t1Minute=minute;
                                Calendar calendar=Calendar.getInstance();
                                calendar.set(0,0,0,t1Hour,t1Minute);
                                timer1.setText(DateFormat.format( "hh:mm aa",calendar ));

                            }
                        },12,0,false
                );
                timePickerDialog.updateTime(t1Hour,t1Minute);
                timePickerDialog.show();

            }
        });

    }
}