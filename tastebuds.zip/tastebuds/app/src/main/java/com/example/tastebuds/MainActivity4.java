package com.example.tastebuds;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class MainActivity4 extends AppCompatActivity {
    ImageButton kbb,cb,mb,ff;
    String choices="";
    Double price=0.00;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);
        kbb=(ImageButton)findViewById(R.id.imagebutton);
        cb=(ImageButton)findViewById(R.id.cb);
        mb=(ImageButton)findViewById(R.id.mb);
        ff=(ImageButton)findViewById(R.id.ff);


    }
    public void add(View view){
        if(view==findViewById(R.id.imagebutton))
        {
            choices=choices+"chicken65"+"\n";
            price=price+80;
        }
        if(view==findViewById(R.id.cb))
        {
            choices=choices+"Chicken Biriyani"+"\n";
            price=price+100;
        }
        if(view==findViewById(R.id.ff))
        {
            choices=choices+"Fish Fry"+"\n";
            price=price+70;
        }
        if(view==findViewById(R.id.mb))
        {
            choices=choices+"Mutton curry"+"\n";
            price=price+90;
        }


}
    public void placeOrder(View view){
        Intent i=new Intent(MainActivity4.this,MainActivity6.class);
        Bundle bundle= new Bundle();
        bundle.putString("choices",choices);
        bundle.putDouble("price",price);
        i.putExtras(bundle);
        startActivity(i);

    }
}